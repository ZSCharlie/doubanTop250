#!/usr/bin/python3
# -*-coding: UTF-8-*-


from urllib import request
import re


class MovieTop250(object):
    def __init__(self):
        self.start = 0
        self.headers = {'User-Agent': 'Mozilla/5.0(Windows NT 6.1; WOW64)'}
        self.movie_list = []
        self.file_top250 = 'D:\数据挖掘大作业\douban.txt'

    def get_html_page(self):
        try:
            url = 'https://movie.douban.com/top250?start=' + str(self.start)
            req = request.Request(url, headers=self.headers)
            res = request.urlopen(req)
            html_page = res.read().decode('UTF-8')
            page_num = (self.start + 25) // 25
            print('正在爬取第' + str(page_num) + '页的数据...')
            self.start += 25
            return html_page
        except Exception as e:
            print('get_html_page函数发生' + e + '异常')

    def get_movie_info(self):
        pattern = re.compile(u'<em.*?class="">(.*?)</em>.*?'
                             + u'<span.*?class="title">(.*?)</span>.*?'
                             + u'<p.*?class="">.*?导演:(.*?)&nbsp;&nbsp;&nbsp;.*?'
                             + u'<br>(.*?)&nbsp;/&nbsp;(.*?)&nbsp;/&nbsp;(.*?)</p>.*?'
                             + u'<span.*?class="rating_num".*?property="v:average">(.*?)</span>.*?'
                             + u'<span>(.*?)人评价</span>.*?'
                             + u'<span.*?class="inq">(.*?)</span>', re.S)
        while self.start <= 225:
            html_page = self.get_html_page()
            movies = re.findall(pattern, html_page)
            for movie in movies:
                self.movie_list.append([movie[0].lstrip().rstrip(),  # 电影排名
                                        movie[1].lstrip().rstrip(),  # 电影名称
                                        movie[2].lstrip().rstrip(),  # 导演姓名
                                        movie[3].lstrip().rstrip(),  # 电影年份
                                        movie[4].lstrip().rstrip().replace(' ', '/'),  # 制作地区
                                        movie[5].lstrip().rstrip().replace(' ', '/'),  # 电影类型
                                        movie[6].lstrip().rstrip() ,  # 电影评分
                                        movie[7].lstrip().rstrip() ,  # 参评人数
                                        movie[8].lstrip().rstrip()])  # 简短影评

    def write_top250(self):
        print('正在将数据写入TOP250.txt...')
        file_top250 = open(self.file_top250, 'w', encoding='UTF-8')
        try:
            file_top250.write('电影排名    ' + '电影名    ' + '导演姓名    '+'电影年份     '+'制作地区    '+'电影类型     '+'电影评分     ' +'参评人数    '+'简短影评     '+'\n')
            for movie in self.movie_list:
               # file_top250.write(movie[0] +'    ')
                file_top250.write(movie[1] +'    ')
                file_top250.write(movie[2] +'    ')
                file_top250.write(movie[3] +'    ')
                file_top250.write(movie[4] +'    ')
                file_top250.write(movie[5] +'    ')
                file_top250.write(movie[6] +'    ')
                file_top250.write(movie[7] +'    ')
                file_top250.write(movie[8] +'    ')
                file_top250.write('\n')
        except Exception as e:
            print('write_top250函数发生' + e + '异常')
        finally:
            file_top250.close()

    def entrance(self):
        print('开始爬取数据...')
        self.get_movie_info()
        self.write_top250()
        print('数据爬取结束！！！')


if __name__ == '__main__':
    movie_top250 = MovieTop250()
    movie_top250.entrance()
