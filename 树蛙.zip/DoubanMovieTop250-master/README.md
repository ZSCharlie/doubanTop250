
# Python爬取豆瓣电影top250
- [教程地址](http://www.jianshu.com/p/826f8566a7c7)
- 基于python3
- 所需类库Requests，BeautifulSoup
- 代码总共30多行
- [豆瓣电影top250](https://movie.douban.com/top250)
- 抓取结果 ![抓取结果](https://lh3.googleusercontent.com/-T48x8AWLlHs/VySrTzjqyHI/AAAAAAAAAAk/jDOEKAdouAYTdWnIALuTcESG6epx1n-2QCL0B/w394-d-h482-p-rw/Snip20160430_7.png)
